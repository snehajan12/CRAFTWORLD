<!--php code start-->
<?php
session_start();
?>


<?php

include 'dbconnect.php';

if(isset($_POST['submit']))
{

$a=$_POST["name"];
$b=$_POST["email"];
$c=$_POST["mobile"];
$p=md5($_POST["password"]);
$cp = md5($_POST["cpassword"]);

$sql1 = "SELECT * FROM `tbl_login` WHERE email='$b'";

 $res1 = mysqli_query($con, $sql1);


 $sql2 = "SELECT * FROM `tbl_registration` WHERE mobile='$c'";


 $res2 = mysqli_query($con, $sql2);

  if(mysqli_num_rows($res1)>0 || mysqli_num_rows($res2)>0)
  {
      if(mysqli_num_rows($res1)>0)
	{

    echo"<script> alert('This Email is already exist!!! Please choose another one');window.location ='index.php';</script>";

    }
      if(mysqli_num_rows($res2)>0)
      {
      echo"<script> alert('This Mobile is already exist!!! Please choose another one');window.location ='index.php';</script>";


    }

}
if ($cp == $p) {



 $sql3="INSERT INTO `tbl_login`(`email`, `password`,`role_id`,`status`) VALUES ('$b','$p',2,1)";
$res3=mysqli_query($con,$sql3);

$logid="SELECT `log_id` FROM `tbl_login` WHERE `email`='$b'";
$res4=mysqli_query($con,$logid);
while($row=mysqli_fetch_array($res4))
{

  $l=$row["log_id"];
     $sql4="INSERT INTO `tbl_registration`(`name`,`mobile`,`status`) VALUES ('$a','$c',1)";

      $res5 = mysqli_query($con, $sql4);
       if(res5)
      {
      echo"<script> alert('Registration Successful Please Login');window.location ='index.php';</script>";

}
}



}

else {

       echo '<script language="javascript">';
       echo 'alert("Your password does not match")';
       echo '</script>';


}}

 ?>
 <?php

 //database connection page


 if(isset($_POST["submit1"]))
 {
 	$email=$_POST["email"];   //username value from the form
 	$password=md5($_POST["password"]);	//password value from the form

        // $password = encryptIt($pwd);
   $sql6="select * from tbl_login where email='$email' and password ='$password' and status=1"; //sql query to the table
 	$res7=mysqli_query($con,$sql6);  //query executing function

         if($res7)
 {
 	if($fetch=mysqli_fetch_array($res7))
 	{
 		if($fetch['role_id']=='1')
 		{

 			///$_SESSION["name"]=$fetch['name'];
 			$_SESSION["log_id"]=$fetch['log_id'];
 			$_SESSION["email"]=$email;	// setting username as session variable
 	header("location:adminhome");	//home page or the dashboard page to be redirected
 	}
 	elseif($fetch['role_id']==2)
 		{
 		$_SESSION["email"]=$email;	// setting username as session variable
 		$_SESSION["log_id"]=$fetch['log_id'];
 	header("location:userhome.php");
 	}

 }
       else
 {
 echo "<script>alert('invalid credentials!')</script>";

 }


     }

 }
 ?>



<!--php code end-->


















<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>CRAFT WORLD</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/2.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">


    <!--modal style start-->
	<!-- animation css files -->
	<link rel="stylesheet" href="css/animation-aos.css">
	<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all" />
	<!-- //animation css files -->

	<!-- css files -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="css/fontawesome-all.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->

	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<!-- //google fonts -->
<!--modal style end-->

<!--validation style start-->
<!-- Adding oh-autoVal css style -->
<link rel="stylesheet" type="text/css" href="jsval/oh-autoval-style.css">
<!-- Adding jQuery script. It must be before other script files -->
<script src="jsval/jquery.min.js"> </script>
<!-- Adding oh-autoVal script file -->
<script src="jsval/oh-autoval-script.js"></script>
<!--validation style end-->



<!--contact form style start-->
<!-- Bootstrap CSS  -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" media="screen">

    <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">

  <!--contact form style end-->




</head>

<body>
    <!-- Search Wrapper Area Start -->
    <div class="search-wrapper section-padding-100">
        <div class="search-close">
            <i class="fa fa-close" aria-hidden="true"></i>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="search-content">
                        <form action="#" method="get">
                            <input type="search" name="search" id="search" placeholder="Type your keyword...">
                            <button type="submit"><img src="img/core-img/search.png" alt=""></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Search Wrapper Area End -->

    <!-- ##### Main Content Wrapper Start ##### -->
    <div class="main-content-wrapper d-flex clearfix">

        <!-- Mobile Nav (max width 767px)-->
        <div class="mobile-nav">
            <!-- Navbar Brand -->
            <div class="amado-navbar-brand">

                <a href="index.php"><img src="img/core-img/logo.png" alt=""></a>
            </div>
            <!-- Navbar Toggler -->
            <div class="amado-navbar-toggler">
                <span></span><span></span><span></span>
            </div>
        </div>

        <!-- Header Area Start -->
        <header class="header-area clearfix">
            <!-- Close Icon -->
            <div class="nav-close">
                <i class="fa fa-close" aria-hidden="true"></i>
            </div>

            <!-- Logo-->
            <div class="logo">
                <a href="index.php"><img src="img/core-img/1.png" alt=""></a>
            </div>
            <!-- Amado Nav -->
            <nav class="amado-nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a  data-toggle="modal" data-target="#myModal1">Login & Signup</a></li>
                    <li class="active"><a href="about.php">About us</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                    <li><a href="sellerlog.php">Sell on CraftWorld</a></li>
                </ul>
            </nav>
            <!-- Button Group -->

            <!-- Cart Menu -->

            <!-- Social Button -->
            <div class="social-info d-flex justify-content-between">
                <a href="https://in.pinterest.com/"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                <a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="https://www.facebook.com/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://twitter.com/Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            </div>
        </header>
        <!-- Header Area End -->
<!--main content area start-->
      <!-- End Content Section  -->

  <div align="center">
    <h1>About Us</h1>
    <p>
CRAFTWORLD PVT LTD<br>
No.77, 21st Main ,Banashankari 2nd stage, Near B.D.A Complex,<br>
Bangalore<br>
Karnataka<br>
560070<br>
For General and web related queries - please email <br>
info@craftworld.in or call +91-9900061127 <br>
Timings: 09:30 a.m. to 6.00 p.m. (Monday to Saturday)<br>
</p>
  </div>
<!--main content area end-->





     <!-- Modal1 -->
     <!--/Login-->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header text-center">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="login px-4 mx-auto mw-100">
					<h5 class="text-center mb-4">Login Now</h5>
					<form action="index.php" method="post">
						<div class="form-group">
							<label class="mb-2">Email address</label>
							<input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="" required="">
							<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
						</div>
						<div class="form-group">
							<label class="mb-2">Password</label>
							<input type="password" class="form-control" id="password" name="password" placeholder="" required="">
						</div>
						<div class="form-check mb-2">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Check me out</label>
						</div>
                        <button type="submit" class="btn btn-primary submit mt-2" name="submit1">Login</button>
                        <p class="text-center pb-4">
							<a href="#" data-toggle="modal" id="closemodal" data-target="#myModal2" data-dismiss="#modal1" > New to CRAFTWORLD? Create your CRAFTWORLD account</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!--//Login-->
<!--modal end-->

 <!-- Modal2 -->
     <!--/Register-->
     <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header text-center">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body" style="overflow-y: scroll; max-height:85%;  margin-top: 50px; margin-bottom:50px">
				<div class="login px-4 mx-auto mw-100">
					<h5 class="text-center mb-4">Register Now</h5>
					<form action="#" method="post" class="oh-autoval-form">
                    <div class="form-group">
							<label class="mb-2">Your name</label>
							<input type="text" class="form-control av-name" id="name" name="name"  placeholder="" required="" av-message="invalid Name">

						</div>
						<div class="form-group">
							<label class="mb-2">Email address</label>
							<input type="email" class="form-control av-email" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="" required="" av-message="invalid Email">
							<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
						</div>
                        <div class="form-group">
							<label class="mb-2">Mobile number</label>
							<input type="text" class="form-control av-mobile" id="mobile" name="mobile"  placeholder="" required="" av-message="Invalid Mobile Number">
							<small id="emailHelp" class="form-text text-muted">We'll never share your mobile number with anyone else.</small>
						</div>

						<div class="form-group">
							<label class="mb-2">Password</label>
							<input type="password" class="form-control av-password" id="password" name="password" placeholder="" required="" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.">
						</div>
            <div class="form-group">
              <label class="mb-2">Confirm Password</label>
              <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="" required="">
            </div>
						<div class="form-check mb-2">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Check me out</label>
						</div>
						<button type="submit" class="btn btn-primary submit mt-2" name="submit">Sign In</button>
						<p class="text-center pb-4">
							<a href="#" data-toggle="modal" id="showmodal" data-dismiss="#modal1" data-target="#myModal1">Already have an account? Sign in</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!--//Register-->
<!--modal2 end-->
    </div>
    <!-- ##### Main Content Wrapper End ##### -->



    <!-- ##### Footer Area Start ##### -->
    <footer class="footer_area clearfix">
        <div class="container">
            <div class="row align-items-center">
                <!-- Single Widget Area -->
                <div class="col-12 col-lg-4">
                    <div class="single_widget_area">
                        <!-- Logo -->
                        <div class="footer-logo mr-50">
                            <a href="index.html"><img src="img/core-img/logo2.png" alt=""></a>
                        </div>
                        <!-- Copywrite Text -->
                        <p class="copywrite"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | CraftWorld <i class="fa fa-heart-o" aria-hidden="true"></i> <a href="#" target="_blank"></a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    </div>
                </div>
                <!-- Single Widget Area -->
                <div class="col-12 col-lg-8">
                    <div class="single_widget_area">
                        <!-- Footer Menu -->
                        <div class="footer_menu">
                            <nav class="navbar navbar-expand-lg justify-content-end">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#footerNavContent" aria-controls="footerNavContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
                                <div class="collapse navbar-collapse" id="footerNavContent">
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item active">
                                            <a class="nav-link" href="index.html">Home</a>
                                        </li>


                                        <li class="nav-item">
                                            <a class="nav-link" href="about.php">About us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.php">Contact us</a>
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>
<script Type="text/javascript">

$(function() {
    $('#closemodal').click(function() {
    $('#myModal1').modal('hide');
});

$('#showmodal').click(function() {
    $('#myModal1').modal('show');
    $('#myModal2').modal('hide');
});
});
</script>
