<?php
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../index.php');
} ?>



<?php

include '../dbconnect.php';
$sql=mysqli_query($con,"select * from tbl_registration");

$res=mysqli_num_rows($sql);


$sql1=mysqli_query($con,"SELECT * FROM `tbl_login` WHERE role_id=2");

$res1=mysqli_num_rows($sql1);


$sql2=mysqli_query($con,"SELECT * FROM `tbl_login` WHERE role_id=3");

$res2=mysqli_num_rows($sql2);

$sql3=mysqli_query($con,"SELECT * FROM `tbl_product`");

$res3=mysqli_num_rows($sql3);

$sql4=mysqli_query($con,"SELECT * FROM `tbl_bproduct`");

$res4=mysqli_num_rows($sql4);

$sql5=mysqli_query($con,"SELECT * FROM `tbl_order`");

$res5=mysqli_num_rows($sql5);

$d=date("Y-m-d");
$sql6=mysqli_query($con,"SELECT * FROM `tbl_bproduct` WHERE bp_edate < '$d'");

$res6=mysqli_num_rows($sql6);

?>



















<!DOCTYPE HTML>
<html lang="en">

<!-- Mirrored from themes.webmasterdriver.net/ElemoListing/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Mar 2019 05:27:36 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<!-- Title  -->
<title>CRAFT WORLD</title>

<!-- Favicon  -->
<link rel="../icon" href="../img/core-img/2.png">
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<link rel="stylesheet" href="assets/css/dashboard.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">
<!-- Fav and touch icons -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon-icon/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/images/favicon-icon/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
<!-- Google-Font-->
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="dashboard_container">
	<!-- Header -->
	<header id="header">
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
               <div class="navbar-header">
                <div class="logo"> <a href="index.html"><img src="../img/core-img/3.png" alt="image"/></a> </div>
                <div id="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i></div>
              </div>
                <div class="collapse navbar-collapse" id="navigation">
                    <div class="user_nav">
                        <div class="dropdown">
                          <span id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="assets/images/happy-client-01.jpg" alt="img">
                          </span>
                          <ul class="dropdown-menu" aria-labelledby="dLabel">
                            <li><a href="index.php"><i class="fa fa-cogs"></i> Dashboard</a></li>

                            <li><a href="../logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                          </ul>
                        </div>
                    </div>
                    <div class="submit_listing">
                        <a href="#" class="btn outline-btn"></i>admin@gmail.com</a>
                     </div>
                </div>
             </div>
        </nav>
    </header>
	<!-- /Header -->

	<div id="dashboard">
	<!-- Navigation -->
	<div id="dashboard-nav" class="dashboard-nav">
		<ul>
        	<li class="active"><a href="#"><i class="fa fa-cogs"></i> Dashboard</a></li>
			<li><a id="MLabel" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-th-list"></i> View</a>
				<ul class="dropdown-menu" aria-labelledby="MLabel">
					<li><a href="viewproducts.php">Products <span class="nav-tag green"><?php echo $res3 ?></span></a></li>
					<li><a href="viewbproducts.php">Bidding Products <span class="nav-tag yellow"><?php echo $res4 ?></span></a></li>
          <li><a href="viewbdproducts.php">Bidded Products <span class="nav-tag green"><?php echo $res6 ?></span></a></li>
				</ul>
			</li>

			<li><a id="MLabel" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-plus"></i> Add</a>
				<ul class="dropdown-menu" aria-labelledby="MLabel">
					<li><a href="addcategory.php">Category</a></li>

				</ul>
			</li>

			<li><a href="../logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
		</ul>
	</div>
	<!-- Navigation / End -->

	<!-- Content -->
	<div class="dashboard-content">
		<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>Dashboard</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="#">Home</a></li>
							<li>Dashboard</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<!-- Notice -->

        <div class="row">
            <div class="dashboard-info-box">
                <div class="dashboard-info color-1">
                    <h4><?php echo $res ?></h4> <span>Registered Members</span>
                </div>
                <div class="dashboard-info color-2">
                    <h4><?php echo $res1 ?></h4> <span>Registered Customers</span>
                </div>
                <div class="dashboard-info color-3">
                    <h4><?php echo $res2 ?></h4> <span>Registered Sellers</span>
                </div>
                <div class="dashboard-info color-4">
                    <h4><?php echo $res3 ?></h4> <span>Total Products</span>
                </div>
                <div class="dashboard-info color-5">
                    <h4><?php echo $res4 ?></h4> <span>Total Bidding Products</span>
                </div>
                <div class="dashboard-info color-6">
                    <h4><?php echo $res5 ?></h4> <span>Total Orders</span>
                </div>
            </div>
        </div>
        <!-- Recent Activity -->

		<div class="row">
			<!-- Copyrights -->
			<div class="col-md-12">
				<div class="copyrights">Copyright &copy; CraftWorld. All Rights Reserved</div>
			</div>
		</div>
	</div>
	<!-- Content / End -->
</div>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/interface.js"></script>
<!--Carousel-JS-->
<script src="assets/js/owl.carousel.min.js"></script>

</body>

<!-- Mirrored from themes.webmasterdriver.net/ElemoListing/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Mar 2019 05:27:40 GMT -->
</html>
