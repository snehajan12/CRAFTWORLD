<?php
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../index.php');
} ?>

<?php
include('../dbconnect.php');

$pid=$_GET['pid'];


								$sql=mysqli_query($con,"SELECT p.pdt_name, p.pdt_id, p.pdt_sprice, p.pdt_cprice, p.pdt_image1, p.pdt_image2, p.pdt_image3, p.pdt_image4, p.pdt_description, c.category_name, r.name, l.role_id FROM tbl_product p JOIN tbl_pcategory c ON p.pc_id = c.pc_id JOIN tbl_registration r ON p.log_id = r.log_id JOIN tbl_login l ON r.log_id=l.log_id WHERE p.pdt_id = '$pid' AND l.role_id='3'");



                $res=mysqli_num_rows($sql);


                if($res==0)
                {
                  echo "no record";
                }






                  ?>












<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<!-- Title  -->
		<title>CRAFT WORLD</title>

		<!-- Favicon  -->
		<link rel="icon" href="../img/core-img/2.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../css/core-style.css">
    <link rel="stylesheet" href="../style.css">

</head>

<body>


    <!-- ##### Main Content Wrapper Start ##### -->
    <div class="main-content-wrapper d-flex clearfix">

        <!-- Mobile Nav (max width 767px)-->
        <div class="mobile-nav">
            <!-- Navbar Brand -->
            <div class="amado-navbar-brand">
                <a href="#"><img src="img/core-img/logo.png" alt=""></a>
            </div>
            <!-- Navbar Toggler -->
            <div class="amado-navbar-toggler">
                <span></span><span></span><span></span>
            </div>
        </div>

				<!-- Header Area Start -->
				<header class="header-area clearfix">
						<!-- Close Icon -->
						<div class="nav-close">
								<i class="fa fa-close" aria-hidden="true"></i>
						</div>

						<!-- Logo-->
						<div class="logo">

						</div>
						<!-- Amado Nav -->
						<nav class="amado-nav">
								<ul>

								</ul>
						</nav>
						<!-- Button Group -->
						<div class="amado-btn-group mt-30 mb-100">

						</div>
						<!-- Cart Menu -->
						<div class="cart-fav-search mb-100">


						</div>
						<!-- Social Button -->
						<div class="social-info d-flex justify-content-between">

						</div>
				</header>
				<!-- Header Area End -->



        <!-- Product Details Area Start -->
        <div class="single-product-area section-padding-100 clearfix">
            <div class="container-fluid">
							<h1>Product Details</h1>
							<?php
									while($row=mysqli_fetch_array($sql))
									 {

										 ?>

                <div class="row">
                    <div class="col-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mt-50">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item"><a href="#"><?php echo $row['category_name'];?></a></li>

                                <li class="breadcrumb-item active" aria-current="page"><?php echo $row['pdt_name'];?></li>
                            </ol>
                        </nav>
                    </div>
                </div>


                <div class="row">
                    <div class="col-12 col-lg-7">
                        <div class="single_product_thumb">
                            <div id="product_details_slider" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li class="active" data-target="#product_details_slider" data-slide-to="0" style="background-image: url(../img/product-img/<?php echo $row['pdt_image1'];?>">
                                    </li>
                                    <li data-target="#product_details_slider" data-slide-to="1" style="background-image: url(../img/product-img/<?php echo $row['pdt_image2'];?>">
                                    </li>
                                    <li data-target="#product_details_slider" data-slide-to="2" style="background-image: url(../img/product-img/<?php echo $row['pdt_image3'];?>">
                                    </li>
                                    <li data-target="#product_details_slider" data-slide-to="3" style="background-image: url(../img/product-img/<?php echo $row['pdt_image4'];?>">
                                    </li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <a class="gallery_img" href="../img/product-img/<?php echo $row['pdt_image1'];?>">
                                            <img class="d-block w-100" src="../img/product-img/<?php echo $row['pdt_image1'];?>" alt="First slide">
                                        </a>
                                    </div>
                                    <div class="carousel-item">
                                        <a class="gallery_img" href="../img/product-img/<?php echo $row['pdt_image2'];?>">
                                            <img class="d-block w-100" src="../img/product-img/<?php echo $row['pdt_image2'];?>" alt="Second slide">
                                        </a>
                                    </div>
                                    <div class="carousel-item">
                                        <a class="gallery_img" href="../img/product-img/<?php echo $row['pdt_image3'];?>">
                                            <img class="d-block w-100" src="../img/product-img/<?php echo $row['pdt_image3'];?>" alt="Third slide">
                                        </a>
                                    </div>
                                    <div class="carousel-item">
                                        <a class="gallery_img" href="../img/product-img/<?php echo $row['pdt_image4'];?>">
                                            <img class="d-block w-100" src="../img/product-img/<?php echo $row['pdt_image4'];?>" alt="Fourth slide">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5">
                        <div class="single_product_desc">
                            <!-- Product Meta Data -->
                            <div class="product-meta-data">
                                <div class="line"></div>
                                <p class="product-price">Selling Price: ₹<?php echo $row['pdt_sprice'];?></p>
																<p class="product-price">Cost Price: ₹<?php echo $row['pdt_cprice'];?></p>
                                <a href="#">
                                    <h6><?php echo $row['pdt_name'];?></h6>
                                </a>
                                <!-- Ratings & Review -->
                                <div class="ratings-review mb-15 d-flex align-items-center justify-content-between">

                                    <div class="review">



                                        <a href="#"><?php echo $row['name'];?></a>
                                    </div>
                                </div>

                            </div>

                            <div class="short_overview my-5">
                                <p><?php echo $row['pdt_description'];?></p>
                            </div>
														<?php
													}
														?>

                            <!-- Add to Cart Form -->
                            <form class="cart clearfix" method="post">
                                <div class="cart-btn d-flex mb-50">

                                </div>
																<a href="viewproducts.php">
                                <button type="button" name="addtocart" value="5" class="btn amado-btn">BACK</button></a>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Product Details Area End -->
    </div>
    <!-- ##### Main Content Wrapper End ##### -->




    <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="../js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../js/plugins.js"></script>
    <!-- Active js -->
    <script src="../js/active.js"></script>

</body>

</html>
