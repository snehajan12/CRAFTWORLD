<?php
include('../dbconnect.php');
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../index.php');
}
?>

<?php
if (isset($_POST['submit'])) {
$a = $_POST['pdt_id'];
$quer = mysqli_query($con, "DELETE FROM `tbl_product` WHERE pdt_id='$a'");
if($quer==1)
{
echo"<script>alert('Product removed');</script>";

}

}
?>




<?php


                $sql=mysqli_query($con,"SELECT p.pdt_name, p.pdt_sprice, p.pdt_image1, p.pdt_id, c.category_name, r.name FROM tbl_product p JOIN tbl_pcategory c ON p.pc_id = c.pc_id JOIN tbl_registration r ON p.log_id = r.log_id");

                $res=mysqli_num_rows($sql);
								// $row=mysqli_fetch_array($res);
								// $name=$row['log_id'];

                if($res==0)
                {
                  echo "no record";
                }


								// $sql1=mysqli_query($con,"select * from tbl_registration where log_id=$name");
								//
                // $res1=mysqli_fetch_array($sql1);
								// $sname=$res1['']





                  ?>




<?php
$sql3=mysqli_query($con,"SELECT * FROM `tbl_product`");

$res3=mysqli_num_rows($sql3);

$sql4=mysqli_query($con,"SELECT * FROM `tbl_bproduct`");

$res4=mysqli_num_rows($sql4);

$d=date("Y-m-d");
$sql6=mysqli_query($con,"SELECT * FROM `tbl_bproduct` WHERE bp_edate < '$d'");

$res6=mysqli_num_rows($sql6);
 ?>















<!DOCTYPE HTML>
<html lang="en">

<!-- Mirrored from themes.webmasterdriver.net/ElemoListing/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Mar 2019 05:27:36 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<!-- Title  -->
<title>CRAFT WORLD</title>

<!-- Favicon  -->
<link rel="../icon" href="../img/core-img/2.png">
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<link rel="stylesheet" href="assets/css/dashboard.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">
<!-- Fav and touch icons -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon-icon/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/images/favicon-icon/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
<!-- Google-Font-->
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="dashboard_container">
	<!-- Header -->
	<header id="header">
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
               <div class="navbar-header">
                <div class="logo"> <a href="#"><img src="../img/core-img/3.png" alt="image"/></a> </div>
                <div id="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i></div>
              </div>
                <div class="collapse navbar-collapse" id="navigation">
                    <div class="user_nav">
                        <div class="dropdown">
                          <span id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="assets/images/happy-client-01.jpg" alt="img">
                          </span>
                          <ul class="dropdown-menu" aria-labelledby="dLabel">
                            <li><a href="index.php"><i class="fa fa-cogs"></i> Dashboard</a></li>

                            <li><a href="../logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                          </ul>
                        </div>
                    </div>
                    <div class="submit_listing">
                        <a href="#" class="btn outline-btn"></i>admin@gmail.com</a>
                     </div>
                </div>
             </div>
        </nav>
    </header>
	<!-- /Header -->

	<div id="dashboard">
	<!-- Navigation -->
	<div id="dashboard-nav" class="dashboard-nav">
		<ul>
        	<li class="active"><a href="index.php"><i class="fa fa-cogs"></i> Dashboard</a></li>
			<li><a id="MLabel" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-th-list"></i> View</a>
				<ul class="dropdown-menu" aria-labelledby="MLabel">
					<li><a href="viewproducts.php">Products <span class="nav-tag green"><?php echo $res3 ?></span></a></li>

					<li><a href="viewbproducts.php">Bidding Products <span class="nav-tag red"><?php echo $res4 ?></span></a></li>
					<li><a href="viewbdproducts.php">Bidded Products <span class="nav-tag green"><?php echo $res6 ?></span></a></li>
				</ul>
			</li>

			<li><a id="MLabel" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-plus"></i> Add</a>
				<ul class="dropdown-menu" aria-labelledby="MLabel">
					<li><a href="addcategory.php">Category</a></li>

				</ul>
			</li>

			<li><a href="../logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
		</ul>
	</div>
	<!-- Navigation / End -->
	<!-- Content -->
	<div class="dashboard-content">
		<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>View Products</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="#">Home</a></li>
							<li><a href="#">View</a></li>
							<li>Products</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

				<div class="row">

			<!-- Listings -->

			<div class="col-lg-12 col-md-12">
				<div class="dashboard-list-box">

					<h4>View Products</h4>


					<ul>
						<?php
								while($row=mysqli_fetch_array($sql))
								 {

									 ?>
						<li>
							<div class="list-box-listing">
								<div class="list-box-listing-img"><a href="#"><img src="../img/product-img/<?php echo $row['pdt_image1'];?>"></img></a></div>
								<div class="list-box-listing-content">

									<div class="inner">
										<input type="hidden" name="pid" value="">
										<h3><a href="viewpdtdtls.php?pid=<?php echo $row['pdt_id']?>"><?php echo $row['pdt_name'];?></a></h3>
										<span><?php echo $row['name'];?></span>
										<div class="star-rating">
											<div class="rating-counter">₹<?php echo $row['pdt_sprice'];?></div>
										</div>
									</div>

								</div>
							</div>
							<form action="#" method="post">
							<div class="buttons-to-right">

                <input type="hidden" name="pdt_id" value="<?php echo $row['pdt_id'];?>">
								<button type="submit" name="submit" id="submit" href="#" class="button red">
									<i class="fa fa-trash-o">
								</i> Remove</button>
							</div>
						</form>
						</li>
						<?php
					}
						?>
					</ul>

				</div>
			</div>


			<!-- Copyrights -->
			<div class="col-md-12">
				<div class="copyrights">Copyright &copy; CraftWorld. All Rights Reserved</div>
			</div>
		</div>

	</div>
	<!-- Content / End -->

</div>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/interface.js"></script>
<!--Carousel-JS-->
<script src="assets/js/owl.carousel.min.js"></script>

</body>

<!-- Mirrored from themes.webmasterdriver.net/ElemoListing/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Mar 2019 05:27:40 GMT -->
</html>
