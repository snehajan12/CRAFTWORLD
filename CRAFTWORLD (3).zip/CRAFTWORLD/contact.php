<!--php code start-->
<?php

include 'dbconnect.php';
session_start();
if(isset($_POST['submit3']))
{

$n=$_POST["name"];
$e=$_POST["email"];
$s=$_POST["subject"];
$m=$_POST["message"];



$sql5="INSERT INTO `tbl_message`(`name`,`email`,`subject`,`message`) VALUES ('$n','$e','$s','$m')";

   $res = mysqli_query($con, $sql5);
   if($res)
   {
       header("location:contact.php?text=Your response has been sent");
   }
}
?>
<!--alert box style start-->
<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>

<!--alert box style end-->

<!--alert box php code start-->


<?php
if(isset($_GET['text']))
{
	$text=$_GET['text'];
	?>
	<div class="alert">
	<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
	<strong><?php echo $text?></strong>
  </div>
  <?php
}
	?>
  <!--alert box php code end-->

<?php


if(isset($_POST['submit']))
{

$a=$_POST["name"];
$b=$_POST["email"];
$c=$_POST["mobile"];
$p=md5($_POST["password"]);
$cp = md5($_POST["cpassword"]);

$sql6 = "SELECT * FROM `tbl_login` WHERE email='$b'";

 $res = mysqli_query($con, $sql6);

$sql5 = "SELECT * FROM `tbl_registration` WHERE mobile='$c'";

 $res1 = mysqli_query($con, $sql5);

  if($res)
	{

    //echo"<script> alert('This Email is already exist!!! Please choose another one');window.location ='index.php';</script>";
    header("location:index.php?text=This Email is already exist!!! Please choose another one");
    }
    if(mysqli_num_rows($res1)>0 ){
     // echo"<script> alert('This Mobile is already exist!!! Please choose another one');window.location ='index.php';</script>";
     header("location:index.php?text=This Mobile is already exist!!! Please choose another one");

    }


if ($cp == $p) {



 $sql1="INSERT INTO `tbl_login`(`email`, `password`,`role_id`,`status`) VALUES ('$b','$p',2,1)";
$result1=mysqli_query($con,$sql1);

$logid="SELECT `log_id` FROM `tbl_login` WHERE `email`='$b'";
$result2=mysqli_query($con,$logid);
while($row=mysqli_fetch_array($result2))
{

  $l=$row["log_id"];
  $sql2="INSERT INTO `tbl_registration`(`name`,`mobile`,`status`) VALUES ('$a','$c',1)";

      $res = mysqli_query($con, $sql2);
header("location:index.php?text=Registration Successful");
}



}

else {

      //  echo '<script language="javascript">';
      //  echo 'alert("Your password does not match")';
      //  echo '</script>';
      header("location:index.php?text=Your password does not match");

}}

 ?>
 <?php

 //database connection page


 if(isset($_POST["submit1"]))
 {
 	$email=$_POST["email"];   //username value from the form
 	$password=md5($_POST["password"]);	//password value from the form

        // $password = encryptIt($pwd);
echo   $sql="select * from tbl_login where email='$email' and password ='$password' and status=1"; //sql query to the table
 	$res=mysqli_query($con,$sql);  //query executing function

         if($res)
 {
 	if($fetch=mysqli_fetch_array($res))
 	{
 		if($fetch['role_id']=='1')
 		{

 			///$_SESSION["name"]=$fetch['name'];
 			$_SESSION["log_id"]=$fetch['log_id'];
 			$_SESSION["email"]=$email;	// setting username as session variable
 	header("location:adminhome");	//home page or the dashboard page to be redirected
 	}
 	elseif($fetch['role_id']==2)
 		{
 		$_SESSION["email"]=$email;	// setting username as session variable
 		$_SESSION["log_id"]=$fetch['log_id'];
 	header("location:userhome.php");
 	}

 }
       else
 {
 echo "<script>alert('invalid credentials!')</script>";
 }


     }
   else{
      echo '<script> alert("Unauthorized access!!!");</script>';
   }
 }
 ?>
 <!--php code for sending message start-->


 <!--php code for sending message end-->



<!--php code end-->

















<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>CRAFT WORLD</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/2.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">


    <!--modal style start-->
	<!-- animation css files -->
	<link rel="stylesheet" href="css/animation-aos.css">
	<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all" />
	<!-- //animation css files -->

	<!-- css files -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="css/fontawesome-all.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->

	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<!-- //google fonts -->
<!--modal style end-->

<!--validation style start-->
<!-- Adding oh-autoVal css style -->
<link rel="stylesheet" type="text/css" href="jsval/oh-autoval-style.css">
<!-- Adding jQuery script. It must be before other script files -->
<script src="jsval/jquery.min.js"> </script>
<!-- Adding oh-autoVal script file -->
<script src="jsval/oh-autoval-script.js"></script>
<!--validation style end-->


<!--form style start-->
<!-- Bootstrap CSS  -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" media="screen">

    <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">

    <!--[if IE 8]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

<!--form style end-->



</head>

<body>
    <!-- Search Wrapper Area Start -->
    <div class="search-wrapper section-padding-100">
        <div class="search-close">
            <i class="fa fa-close" aria-hidden="true"></i>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="search-content">
                        <form action="#" method="get">
                            <input type="search" name="search" id="search" placeholder="Type your keyword...">
                            <button type="submit"><img src="img/core-img/search.png" alt=""></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Search Wrapper Area End -->

    <!-- ##### Main Content Wrapper Start ##### -->
    <div class="main-content-wrapper d-flex clearfix">

        <!-- Mobile Nav (max width 767px)-->
        <div class="mobile-nav">
            <!-- Navbar Brand -->
            <div class="amado-navbar-brand">

                <a href="index.html"><img src="img/core-img/logo.png" alt=""></a>
            </div>
            <!-- Navbar Toggler -->
            <div class="amado-navbar-toggler">
                <span></span><span></span><span></span>
            </div>
        </div>

        <!-- Header Area Start -->
        <header class="header-area clearfix">
            <!-- Close Icon -->
            <div class="nav-close">
                <i class="fa fa-close" aria-hidden="true"></i>
            </div>

            <!-- Logo-->
            <div class="logo">
                <a href="index.php"><img src="img/core-img/1.png" alt=""></a>
            </div>
            <!-- Amado Nav -->
            <nav class="amado-nav">
                <ul>
                    <li class="active"><a href="index.php">Home</a></li>
                    <li><a  data-toggle="modal" data-target="#myModal1">Login & Signup</a></li>
                    <li><a href="about.php">About us</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                    <li><a href="sellerlog.php">Sell on CraftWorld</a></li>
                </ul>
            </nav>
            <!-- Button Group -->
            <div class="amado-btn-group mt-30 mb-100">
                <a href="#" class="btn amado-btn mb-15">%Discount%</a>
                <a href="#" class="btn amado-btn active">New this week</a>
            </div>
            <!-- Cart Menu -->
            <div class="cart-fav-search mb-100">

                <a href="#" class="search-nav"><img src="img/core-img/search.png" alt=""> Search</a>
            </div>
            <!-- Social Button -->
            <div class="social-info d-flex justify-content-between">
                <a href="https://in.pinterest.com/"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                <a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="https://www.facebook.com/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://twitter.com/Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            </div>
        </header>
        <!-- Header Area End -->


        <!-- Start Content Section -->
        <section id="content">
          <div class="container">
            <div class="row">
              <div class="col-md-9">
                <h2>Contact Form</h2>

              <!-- Start Contact Form -->
              <form  action="#" method="post">
                <div class="form-group">
                  <div class="controls">
                    <input type="text" id="name" name="name" class="form-control" placeholder="Name" required data-error="Please enter your name">
                    <div class="help-block with-errors"></div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="controls">
                    <input type="email" class="email form-control" id="email" name="email" placeholder="Email" required data-error="Please enter your email">
                    <div class="help-block with-errors"></div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="controls">
                    <input type="text" id="subject" name="subject" class="form-control" placeholder="Subject" required data-error="Please enter your message subject">
                    <div class="help-block with-errors"></div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="controls">
                    <textarea id="message" name="message" rows="7" placeholder="Message" class="form-control" required data-error="Write your message"></textarea>
                    <div class="help-block with-errors"></div>
                  </div>
                </div>

                  <button type="submit" class="btn btn-primary submit mt-2" name="submit3">Send Message</button>
              <!--  <div id="msgSubmit" class="h3 text-center hidden"></div>-->
                <div class="clearfix"></div>

              </form>
              <!-- End Contact Form -->

              </div>
              <div class="col-md-3">
                <h2 class="big-title">Contact Info</h2>
                <div class="information">
                  <div class="contact-datails">
                    CRAFTWORLD PVT LTD<br>
                    No.77, 21st Main ,Banashankari 2nd stage, Near B.D.A Complex,<br>
                    Bangalore<br>
                    Karnataka<br>
                    560070<br>
                    For General and web related queries - please email <br>
                    infO@craftworld.in or call +91-9900061127 <br>
                    Timings: 09:30 a.m. to 6.00 p.m. (Monday to Saturday)<br>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- End Content Section  -->

      </div>

      <!-- Main JS  -->
      <script type="text/javascript" src="assets/js/jquery-min.js"></script>
      <script type="text/javascript" src="assets/js/form-validator.min.js"></script>
      <script type="text/javascript" src="assets/js/contact-form-script.js"></script>







     <!-- Modal1 -->
     <!--/Login-->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header text-center">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="login px-4 mx-auto mw-100">
					<h5 class="text-center mb-4">Login Now</h5>
					<form action="index.php" method="post">
						<div class="form-group">
							<label class="mb-2">Email address</label>
							<input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="" required="">
							<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
						</div>
						<div class="form-group">
							<label class="mb-2">Password</label>
							<input type="password" class="form-control" id="password" name="password" placeholder="" required="">
						</div>
						<div class="form-check mb-2">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Check me out</label>
						</div>
                        <button type="submit" class="btn btn-primary submit mt-2" name="submit1">Login</button>
                        <p class="text-center pb-4">
							<a href="#" data-toggle="modal" id="closemodal" data-target="#myModal2" data-dismiss="#modal1" > New to CRAFTWORLD? Create your CRAFTWORLD account</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!--//Login-->
<!--modal end-->

 <!-- Modal2 -->
     <!--/Register-->
     <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header text-center">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body" style="overflow-y: scroll; max-height:85%;  margin-top: 50px; margin-bottom:50px">
				<div class="login px-4 mx-auto mw-100">
					<h5 class="text-center mb-4">Register Now</h5>
					<form action="#" method="post" class="oh-autoval-form">
                    <div class="form-group">
							<label class="mb-2">Your name</label>
							<input type="text" class="form-control av-name" id="name" name="name"  placeholder="" required="" av-message="invalid Name">

						</div>
						<div class="form-group">
							<label class="mb-2">Email address</label>
							<input type="email" class="form-control av-email" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="" required="" av-message="invalid Email">
							<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
						</div>
                        <div class="form-group">
							<label class="mb-2">Mobile number</label>
							<input type="text" class="form-control av-mobile" id="mobile" name="mobile"  placeholder="" required="" av-message="Invalid Mobile Number">
							<small id="emailHelp" class="form-text text-muted">We'll never share your mobile number with anyone else.</small>
						</div>

						<div class="form-group">
							<label class="mb-2">Password</label>
							<input type="password" class="form-control av-password" id="password" name="password" placeholder="" required="" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.">
						</div>
            <div class="form-group">
              <label class="mb-2">Confirm Password</label>
              <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="" required="">
            </div>
						<div class="form-check mb-2">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Check me out</label>
						</div>
						<button type="submit" class="btn btn-primary submit mt-2" name="submit">Sign In</button>
						<p class="text-center pb-4">
							<a href="#" data-toggle="modal" id="showmodal" data-dismiss="#modal1" data-target="#myModal1">Already have an account? Sign in</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!--//Register-->
<!--modal2 end-->
    </div>
    <!-- ##### Main Content Wrapper End ##### -->



    <!-- ##### Footer Area Start ##### -->
    <footer class="footer_area clearfix">
        <div class="container">
            <div class="row align-items-center">
                <!-- Single Widget Area -->
                <div class="col-12 col-lg-4">
                    <div class="single_widget_area">
                        <!-- Logo -->
                        <div class="footer-logo mr-50">
                            <a href="index.html"><img src="img/core-img/logo2.png" alt=""></a>
                        </div>
                        <!-- Copywrite Text -->
                        <p class="copywrite"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | CraftWorld <i class="fa fa-heart-o" aria-hidden="true"></i> <a href="#" target="_blank"></a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    </div>
                </div>
                <!-- Single Widget Area -->
                <div class="col-12 col-lg-8">
                    <div class="single_widget_area">
                        <!-- Footer Menu -->
                        <div class="footer_menu">
                            <nav class="navbar navbar-expand-lg justify-content-end">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#footerNavContent" aria-controls="footerNavContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
                                <div class="collapse navbar-collapse" id="footerNavContent">
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item active">
                                            <a class="nav-link" href="index.html">Home</a>
                                        </li>


                                        <li class="nav-item">
                                            <a class="nav-link" href="about.php">About us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.php">Contact us</a>
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>
<script Type="text/javascript">

$(function() {
    $('#closemodal').click(function() {
    $('#myModal1').modal('hide');
});

$('#showmodal').click(function() {
    $('#myModal1').modal('show');
    $('#myModal2').modal('hide');
});
});
</script>
