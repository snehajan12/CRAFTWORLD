<?php

 include("../dbconnection.php");
$district=array();
$i=0;

$did=$_POST['did'];
$sql="SELECT * FROM tbl_district WHERE distid='$did' ";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    {
                        $id=$row['did'];
                        $name=$row['dname'];
                        $district[$i]['id']=$id;
                        $district[$i]['value']=$name;
                        $i++;

                    }
     echo json_encode($district);
     ?>
