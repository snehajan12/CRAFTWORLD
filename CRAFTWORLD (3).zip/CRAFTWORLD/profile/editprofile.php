<?php
include("../dbconnect.php");
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../index.php');
}



?>


<?php
require_once("dbcontroller.php");
$db_handle = new DBController();



if(isset($_POST['submit']))
{
$id=$_SESSION['log_id'];
$pi=time().$_FILES['pimage']['name'];
$m=$_POST["mobile"];
$ci=$_POST["cname"];
$hn=$_POST["hname"];


move_uploaded_file($_FILES['pimage']['tmp_name'],"images/profile-images/".$pi);


$sql2="UPDATE `tbl_profile` SET `p_image`='$pi', `c_id`='$ci', `hname`='$hn' WHERE `log_id`=$id";

   $res = mysqli_query($con, $sql2);
	 $sql3="UPDATE `tbl_registration` SET `mobile`='$m' WHERE `log_id`=$id";

	    $res3 = mysqli_query($con, $sql3);
}

 ?>






<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
	<!-- Title  -->
	<title>CRAFT WORLD</title>
	<script src="jquery-3.2.1.min.js" type="text/javascript"></script>
	<script>
function getDistrict(val) {
	$.ajax({
	type: "POST",
	url: "getDistrict.php",
	data:'state_id='+val,
	success: function(data){
		$("#dname").html(data);
		getCity();
	}
	});
}


function getCity(val) {
	$.ajax({
	type: "POST",
	url: "getCity.php",
	data:'city_id='+val,
	success: function(data){
		$("#cname").html(data);
	}
	});
}

</script>




	<!-- Favicon  -->
	<link rel="icon" href="../img/core-img/2.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Profile Contact Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="//fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
<!-- //web font -->
</head>
<body>
	<!-- main -->
	<div class="main">
		<h1>My Profile</h1>

		<?php
		$id=$_SESSION['log_id'];
		$sql1=mysqli_query($con,"SELECT r.name, r.mobile, l.email, p.gender, p.hname, p.p_image, p.dob, c.c_name, d.dname, s.sname FROM tbl_registration r JOIN tbl_login l ON r.log_id = l.log_id JOIN tbl_profile p ON l.log_id = p.log_id JOIN tbl_city c ON p.c_id = c.c_id JOIN tbl_district d ON c.d_id = d.did JOIN tbl_state s ON d.sid = s.id WHERE p.log_id = '$id' AND p.c_id = c.c_id");



		$res=mysqli_num_rows($sql1);


		if($res==0)
		{
			echo "no record";
		}

				while($row1=mysqli_fetch_array($sql1))
				 {

					 ?>
		<div class="main-wthree-row">

			<div class="agileits-info">
				<div class="agileits-infoleft">
					<form action="#" method="post" name="form1" id="form1" enctype="multipart/form-data">
					<img src="images/profile-images/<?php echo $row1['p_image'];?>" alt=""/>
					<input type="file" name="pimage" id="pimage">
					<div class="agileits-infotext">
						<h2><?php echo $row1['name'];?></h2>

					</div>
				</div>
				<div class="agileits-inforight">
					<p><img src="images/i1.png" alt=""><?php echo $row1['mobile'];?></p>
					<p><img src="images/i2.png" alt=""> <a href="#"><?php echo $row1['email'];?></a></p>
				</div>
				<div class="clear"> </div>
			</div>

			<div class="contact-wthree">

					<div class="contact-w3left w3-agile">
						<label>Name</label>
						<input type="text" name="User Name" placeholder="Name" required="" value="<?php echo $row1['name'];?>" readonly>
						<label>Mobile</label>
						<input type="text" class="email" name="mobile" placeholder="Mobile Number" required="" value="<?php echo $row1['mobile'];?>">
            <label>Gender</label>
						<input type="text" name="gender" value="<?php echo $row1['gender'];?>" readonly>

						<label>Age</label>
						<input type="text" name="bday" value="<?php echo $row1['dob'];?>" readonly>

						<label>Country</label>
						<input type="text"  name="country" id="country" placeholder="INDIA" required="" readonly>



					</div>
					<div class="contact-w3right">

						<label>State</label>


						<select name="state" id="state" onChange="getDistrict(this.value);" required style="width:200px;height:37px;" >
							<option value="<?php echo $row1['sname'];?>"><?php echo $row1['sname'];?></option>
							<?php

									 $sql="SELECT * FROM tbl_state";
									 $result=mysqli_query($con,$sql);
									 while($row=mysqli_fetch_array($result))
									 {
											 $id=$row['id'];
											 $name=$row['sname'];
											 ?>

											 <option value='<?php echo $id ?>'><?php echo $name ?></option>";
											 <?php
									 }
									 ?>
									 </select>
									 <label>District</label>
									 <select name="dname" id="dname" onChange="getCity(this.value);" style="width:200px;height:37px;">
			 							<option value="<?php echo $row1['dname'];?>"><?php echo $row1['dname'];?></option>
									</select>
									<label>City</label>
									<select name="cname" id="cname"  style="width:200px;height:37px;">
									                <option value="<?php echo $row1['c_name'];?>"><?php echo $row1['c_name'];?></option>
									            </select>
															<label>House Name</label>

															<input type="text"  name="hname" id="hname" value="<?php echo $row1['hname'];?>" required="">
														<?php } ?>
						<input type="submit" value="SUBMIT" name="submit" id="submit">
							<a href="../userhome/userhome.php">	<p>Back to Home</p></a>
					</div>

					<div class="clear"> </div>
				</form>
			</div>
		</div>

	</div>
	<!-- //main -->
	<!-- copyright -->
	<div class="w3copyright-agile">
		<p>All rights reserved©CraftWorld</p>
	</div>
	<!-- //copyright -->
</body>
</html>
