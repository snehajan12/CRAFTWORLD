<?php
require_once ("dbcontroller.php");
$db_handle = new DBController();
if (! empty($_POST["city_id"])) {
    $query = "SELECT * FROM tbl_city WHERE d_id = '" . $_POST["city_id"] . "'";
    $results = $db_handle->runQuery($query);
    ?>
<option value disabled selected>Select city</option>
<?php
    foreach ($results as $city) {
        ?>
<option value="<?php echo $city["c_id"]; ?>"><?php echo $city["c_name"]; ?></option>
<?php
    }
}
?>
