<?php
include("../dbconnect.php");
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../index.php');
}
$id=$_SESSION['log_id'];
$sql=mysqli_query($con,"SELECT * FROM tbl_profile p JOIN tbl_login l ON p.log_id = l.log_id WHERE p.log_id=$id");
$num=mysqli_num_rows($sql);
//print_r($num);
if($num!=0)
{
header('location:viewprofile.php');

}
else {



?>


<?php
require_once("dbcontroller.php");
$db_handle = new DBController();



if(isset($_POST['submit']))
{
$id=$_SESSION['log_id'];
$pi=time().$_FILES['pimage']['name'];
$g=$_POST["gender"];
$d=$_POST["bday"];
$ci=$_POST["cname"];
$hn=$_POST["hname"];


move_uploaded_file($_FILES['pimage']['tmp_name'],"images/profile-images/".$pi);


$sql2="INSERT INTO `tbl_profile`(`log_id`,`p_image`,`gender`,`dob`,`c_id`,`hname`) VALUES ('$id','$pi','$g','$d','$ci','$hn')";

   $res = mysqli_query($con, $sql2);
}

 ?>






<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
	<!-- Title  -->
	<title>CRAFT WORLD</title>
	<script src="jquery-3.2.1.min.js" type="text/javascript"></script>
	<script>
function getDistrict(val) {
	$.ajax({
	type: "POST",
	url: "getDistrict.php",
	data:'state_id='+val,
	success: function(data){
		$("#dname").html(data);
		getCity();
	}
	});
}


function getCity(val) {
	$.ajax({
	type: "POST",
	url: "getCity.php",
	data:'city_id='+val,
	success: function(data){
		$("#cname").html(data);
	}
	});
}

</script>




	<!-- Favicon  -->
	<link rel="icon" href="../img/core-img/2.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Profile Contact Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="//fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
<!-- //web font -->
<!--validation-->
<link href="https://clientval.ml/cv-resources/1.9.3/css/clientval-style.css" rel="stylesheet"/>
<script src="https://clientval.ml/cv-resources/1.9.3/js/clientval-script.js" cv-key=jiUwpkIZ4tb2></script>
<!--validation end-->
</head>
<body>
	<!-- main -->
	<div class="main">
		<h1>My Profile</h1>

		<?php
		$id=$_SESSION['log_id'];
		$sql=mysqli_query($con,"SELECT r.name, r.mobile, l.email FROM tbl_registration r JOIN tbl_login l ON r.log_id = l.log_id WHERE r.log_id=$id");



		$res=mysqli_num_rows($sql);


		if($res==0)
		{
			echo "no record";
		}

				while($row=mysqli_fetch_array($sql))
				 {

					 ?>
		<div class="main-wthree-row">

			<div class="agileits-info">
				<div class="agileits-infoleft">
					<form action="#" method="post" name="form1" id="form1" enctype="multipart/form-data">
					<img src="images/img1.jpg" alt=""/>
					<input type="file" name="pimage" id="pimage">
					<div class="agileits-infotext">
						<h2><?php echo $row['name'];?></h2>

					</div>
				</div>
				<div class="agileits-inforight">
					<p><img src="images/i1.png" alt=""><?php echo $row['mobile'];?></p>
					<p><img src="images/i2.png" alt=""> <a href="#"><?php echo $row['email'];?></a></p>
				</div>
				<div class="clear"> </div>
			</div>

			<div class="contact-wthree">

					<div class="contact-w3left w3-agile">
						<input type="text" name="User Name" placeholder="Name" required="" value="<?php echo $row['name'];?>" readonly>
						<input type="text" class="email cv-name" name="Number" placeholder="Mobile Number" required="" value="<?php echo $row['mobile'];?>" readonly>
						<?php } ?>
						<input type="radio" name="gender" value="male"> Male
            <input type="radio" name="gender" value="female"> Female<br>
						<input type="date" name="bday">
						<input type="text"  name="country" id="country" placeholder="INDIA" required="" readonly>


					</div>
					<div class="contact-w3right">
						<select name="state" id="state" onChange="getDistrict(this.value);" required style="width:200px;height:37px;" >
							<option>--select state--</option>
							<?php

									 $sql="SELECT * FROM tbl_state";
									 $result=mysqli_query($con,$sql);
									 while($row=mysqli_fetch_array($result))
									 {
											 $id=$row['id'];
											 $name=$row['sname'];
											 ?>

											 <option value='<?php echo $id ?>'><?php echo $name ?></option>";
											 <?php
									 }
									 ?>
									 </select>
									 <select name="dname" id="dname" onChange="getCity(this.value);" style="width:200px;height:37px;">
			 							<option value="">--select District--</option>
									</select>
									<select name="cname" id="cname"  style="width:200px;height:37px;">
									                <option value="">Select city</option>
									            </select>
															<input type="text"  name="hname" id="hname" placeholder="HOUSE NAME" required="">
						<input type="submit" value="SUBMIT" name="submit" id="submit">
					</div>
					<div class="clear"> </div>
				</form>
			</div>
		</div>

	</div>
	<!-- //main -->
	<!-- copyright -->
	<div class="w3copyright-agile">
		<p>©All rights reserved<a href="#" target="_blank">CraftWorld</a></p>
	</div>
	<!-- //copyright -->
</body>
</html>
<?php } ?>
