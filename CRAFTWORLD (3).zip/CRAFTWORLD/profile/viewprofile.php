<?php
include("../dbconnect.php");
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../index.php');
}
?>

<?php
$id=$_SESSION['log_id'];
$sql=mysqli_query($con,"SELECT r.name, r.mobile, l.email, p.gender, p.p_image, p.hname, p.dob, c.c_name, d.dname, s.sname FROM tbl_registration r JOIN tbl_login l ON r.log_id = l.log_id JOIN tbl_profile p ON l.log_id = p.log_id JOIN tbl_city c ON p.c_id = c.c_id JOIN tbl_district d ON c.d_id = d.did JOIN tbl_state s ON d.sid = s.id WHERE p.log_id = '$id' AND p.c_id = c.c_id");



$res=mysqli_num_rows($sql);


if($res==0)
{
	echo "no record";
}

?>






<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>CRAFT WORLD</title>
<link rel="icon" href="../img/core-img/2.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Profile Contact Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="//fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
<!-- //web font -->
</head>
<body>
	<!-- main -->
	<div class="main">
		<h1>My Profile</h1>
		<div class="main-wthree-row">

			<div class="agileits-info">
				<div class="agileits-infoleft">
					<?php
					while($row=mysqli_fetch_array($sql))
					 {
          // $a=$row['dob'];
					// $b=date("y-m-d");
					 //$c=date_diff($a,$b);
					 //echo $c->format("%R%a years");



					 ?>
					<img src="images/profile-images/<?php echo $row['p_image'];?>" alt=""/>
					<div class="agileits-infotext">

						<h2><?php echo $row['name'];?></h2>

					</div>
				</div>
				<div class="agileits-inforight">
					<p><img src="images/i1.png" alt=""> <?php echo $row['mobile'];?></p>
					<p><img src="images/i2.png" alt=""> <a href="#"> <?php echo $row['email'];?></a></p>
				</div>
				<div class="clear"> </div>
			</div>

			<div class="contact-wthree">
				<form action="#" method="post">
					<div class="contact-w3left w3-agile">
						<label>Name</label>
						<input type="text" name="User Name" value="<?php echo $row['name'];?>"  required="" readonly>
						<label>Mobile Number</label>
						<input type="text" class="email" name="Number" value="<?php echo $row['mobile'];?>"  required="" readonly>
						<label>Email</label>
						<input type="email" name="Email" value="<?php echo $row['email'];?>" required="" readonly>
						<label>Gender</label>
						<input type="email" name="Email" value="<?php echo $row['gender'];?>" required="" readonly>
						<label>Age</label>
						<input type="email" name="Email" value="<?php echo $row['dob'];?>" required="" readonly>
					</div>
					<div class="contact-w3right">
						<label>Country</label>
						<input type="email" name="Email" placeholder="INDIA" required="" readonly>
						<label>State</label>
						<input type="email" name="Email" value="<?php echo $row['sname'];?>" required="" readonly>
						<label>District</label>
						<input type="email" name="Email" value="<?php echo $row['dname'];?>" required="" readonly>
						<label>City</label>
						<input type="email" name="Email" value="<?php echo $row['c_name'];?>" required="" readonly>
						<label>House Name</label>
						<input type="email" name="Email" value="<?php echo $row['hname'];?>" required="" readonly>

						<a href="editprofile.php"><input type="button" value="EDIT"></a>
					<a href="../userhome/userhome.php">	<p>Back to Home</p></a>
					<?php } ?>
					</div>
					<div class="clear"> </div>
				</form>
			</div>
		</div>
	</div>
	<!-- //main -->
	<!-- copyright -->
	<div class="w3copyright-agile">
		<p>All rights reserved©CraftWorld</p>
	</div>
	<!-- //copyright -->
</body>
</html>
