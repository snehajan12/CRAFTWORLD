<?php
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../index.php');
} ?>






<?php

include '../dbconnect.php';

if(isset($_POST['submit']))
{

  $cn=$_POST["cname"];
  $pn=$_POST["pname"];
  $id=$_SESSION["log_id"];

  $cp=$_POST["cprice"];
  $sp=$_POST["sprice"];
	$pc=$_POST["pcolor"];
  $im1=time().$_FILES['image1']['name'];
	$im2=time().$_FILES['image2']['name'];
	$im3=time().$_FILES['image3']['name'];
	$im4=time().$_FILES['image4']['name'];
  $dp=$_POST["description"];
	$d=date("Y-m-d");




  move_uploaded_file($_FILES['image1']['tmp_name'],"../img/product-img/".$im1);
	move_uploaded_file($_FILES['image2']['tmp_name'],"../img/product-img/".$im2);
	move_uploaded_file($_FILES['image3']['tmp_name'],"../img/product-img/".$im3);
	move_uploaded_file($_FILES['image4']['tmp_name'],"../img/product-img/".$im4);

  $sql2="INSERT INTO `tbl_product`(`pc_id`,`pdt_name`,`log_id`,`pdt_cprice`,`pdt_sprice`,`pdt_color`,`pdt_image1`,`pdt_image2`,`pdt_image3`,`pdt_image4`,`pdt_description`,`date`) VALUES ('$cn','$pn','$id','$cp','$sp','$pc','$im1','$im2','$im3','$im4','$dp','$d')";
  $res = mysqli_query($con, $sql2);
	if($res)
	{
		echo"<script> alert('Product added successfully');window.location ='addproduct.php';</script>";
	}
}



?>













<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="description" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

  <!-- Title  -->
  <title>CraftWorld</title>

  <!-- Favicon  -->
  <link rel="icon" href="../img/core-img/2.png">

  <!-- Core Style CSS -->
  <link rel="stylesheet" href="../css/core-style.css">
  <link rel="stylesheet" href="../style.css">

  <script src="../asset/js/jquery-3.3.1.min.js"></script>
	<!--validation-->
	<link href="https://clientval.ml/cv-resources/1.9.3/css/clientval-style.css" rel="stylesheet"/>
<script src="https://clientval.ml/cv-resources/1.9.3/js/clientval-script.js" cv-key=jiUwpkIZ4tb2></script>
	<!--validation end-->

</head>

<body>
  <!-- Search Wrapper Area Start -->
  <div class="search-wrapper section-padding-100">
    <div class="search-close">
      <i class="fa fa-close" aria-hidden="true"></i>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="search-content">
            <form action="#" method="get">
              <input type="search" name="search" id="search" placeholder="Type your keyword...">
              <button type="submit"><img src="../img/core-img/search.png" alt=""></button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Search Wrapper Area End -->

  <!-- ##### Main Content Wrapper Start ##### -->
  <div class="main-content-wrapper d-flex clearfix">

    <!-- Mobile Nav (max width 767px)-->
    <div class="mobile-nav">
      <!-- Navbar Brand -->
      <div class="amado-navbar-brand">
        <a href="#"><img src="../img/core-img/1.png" alt=""></a>
      </div>
      <!-- Navbar Toggler -->
      <div class="amado-navbar-toggler">
        <span></span><span></span><span></span>
      </div>
    </div>

    <!-- Header Area Start -->
    <header class="header-area clearfix">
      <!-- Close Icon -->
      <div class="nav-close">
        <i class="fa fa-close" aria-hidden="true"></i>
      </div>
      <!-- Logo -->
      <div class="logo">
        <a href="#"><img src="../img/core-img/1.png" alt=""></a>
      </div>
      <!-- Amado Nav -->
      <nav class="amado-nav">
        <ul>
          <li><a href="sellerhome.php">Home</a></li>

          <li><a href="profile/index.php">Profile</a></li>
          <li class="active"><a href="#">Product</a></li>
					<li><a href="biddingzone/biddinghome.php">Bidding Zone</a></li>


        </ul>
      </nav>
      <!-- Button Group -->

      <!-- Cart Menu -->
      <div class="cart-fav-search mb-100">

        <a href="../logout.php" class="search-nav"><img src="../img/core-img/l.png" alt=""> Logout</a>
      </div>
      <!-- Social Button -->
      <div class="social-info d-flex justify-content-between">
        <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
      </div>
    </header>
    <!-- Header Area End -->
<!--add product form start-->
<div>

<table class="table table-condensed">
  <th><font color = "black" size="6" ><b>Enter Product Details</b></center></font></th>
				<form name="form_edit1" class="cv-form" enctype="multipart/form-data" action="#" method="post" onsubmit="return">
				 <tr><td><label><b>&nbsp; &nbsp; &nbsp; Select Category</b></label></td><td>
           <select name="cname" id="cname">
                       <option value="">Select Category</option>
                       <?php $cn=mysqli_query($con,"select pc_id,category_name from tbl_pcategory where status=1");
                       while ($row=mysqli_fetch_array($cn)) {
                         echo '<option value=' . $row['pc_id'] . '>' . $row['category_name'] .'</option>';
                         // select category name
                       } ?>
                     </select>
</td></tr>



  </td></tr>
					<tr><td><label><b>&nbsp; &nbsp; &nbsp; Product Name</b></label></td><td>
            <input type="text" class="form-control" Name="pname" id="pname" placeholder="Enter Product Name" ></td></tr>


					<br>
        </td></tr>

                      <tr><td><label><b>&nbsp; &nbsp; &nbsp; Cost Price</b></label></td><td>
                        <input type="text" class="form-control" Name="cprice" id="cprice" placeholder="Enter Cost Price" ></td></tr>


                      <br>
                    </td></tr>
                            <tr><td><label><b>&nbsp; &nbsp; &nbsp; Selling Price</b></label></td><td>
                              <input type="text" class="form-control" Name="sprice" id="sprice" placeholder="Enter Selling Price" ></td></tr>


                            <br>
                          </td></tr>
													<tr><td><label><b>&nbsp; &nbsp; &nbsp; Product Color</b></label></td><td>
								            <input type="text" class="form-control" Name="pcolor" id="pcolor" placeholder="Enter Product Color" ></td></tr>


													<br>
                                  <tr><td><label><b>&nbsp; &nbsp; &nbsp; Image 1</b></label></td><td>
                                    <input type="file" class="form-control" Name="image1" id="image1" placeholder="Enter Product Name" ></td></tr>


                                  <br>
                                </td></tr>
																<tr><td><label><b>&nbsp; &nbsp; &nbsp; Image 2</b></label></td><td>
																	<input type="file" class="form-control" Name="image2" id="image2" placeholder="Enter Product Name" ></td></tr>


																<br>
															</td></tr>
															<tr><td><label><b>&nbsp; &nbsp; &nbsp; Image 3</b></label></td><td>
																<input type="file" class="form-control" Name="image3" id="image3" placeholder="Enter Product Name" ></td></tr>


															<br>
														</td></tr>
														<tr><td><label><b>&nbsp; &nbsp; &nbsp; Image 4</b></label></td><td>
															<input type="file" class="form-control" Name="image4" id="image4" placeholder="Enter Product Name" ></td></tr>


														<br>
													</td></tr>

                                        <tr><td><label><b>&nbsp; &nbsp; &nbsp; Description</b></label></td><td>
                                          <textarea class="form-control" Name="description" id="description" placeholder="Enter Product Description" >
                                          </textarea></td></tr>


                                        <br>
						<tr><td colspan="2" align="center"> <br>
            <input type="submit" class="btn btn-primary" value="Add" name="submit" onClick="return vali()"></td></tr>





				</form>
                </table>

</div>



<!--add product form end-->

















<!-- ##### Footer Area Start ##### -->
<footer class="footer_area clearfix">
  <div class="container">
    <div class="row align-items-center">
      <!-- Single Widget Area -->
      <div class="col-12 col-lg-4">
        <div class="single_widget_area">
          <!-- Logo -->
          <div class="footer-logo mr-50">
            <a href="#"><img src="../img/core-img/logo2.png" alt=""></a>
          </div>
          <!-- Copywrite Text -->
          <p class="copywrite"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
        <!-- Single Widget Area -->
        <div class="col-12 col-lg-8">
          <div class="single_widget_area">
            <!-- Footer Menu -->
            <div class="footer_menu">
              <nav class="navbar navbar-expand-lg justify-content-end">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#footerNavContent" aria-controls="footerNavContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
                <div class="collapse navbar-collapse" id="footerNavContent">
                  <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                      <a class="nav-link" href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="shop.html">Shop</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="product-details.html">Product</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="cart.html">Cart</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="checkout.html">Checkout</a>
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- ##### Footer Area End ##### -->


  <!--ajax start-->



  <script>

  $(document).ready(function() {
    $("#cname").on("change", function(){
      var cn = $('#cname').val();

      $.ajax({
        type:'post',
        data:{'index':cn},
        url:'getscategory.php',
        success:function(data){
          //alert(document.getElementById('sname2').value);

          var data1 = JSON.parse(data);
          //document.getElementById('sname').html("");
        //  document.getElementById('sname').html('<option selected disabled>--SELECT SUBCATEGORY--</option>');
          //alert(data1.length);
          t="";
          for(i=0;i<data1.length;i++){

            t=t+'<option value="'+data1[i].subc_id+'">' + data1[i].subc_name+ '</option>';

          }
          $('#test').html('<select name="sname" id="sname" style="height:40px; color: rgb(100,100,100)">\
                              <option>Select Subcategory</option>'+t+'\
                            </select>');
          /*foreach(data1, function(key,value){
            alert(key,value);
            $('#sname').append('<option value="'+value.subc_id+'">' + subc_name+ '</option>');

          })*/
          {

          }

        }
      });
    });
  });
</script>
<!--ajax end-->


<!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
<script src="../js/jquery/jquery-2.2.4.min.js"></script>
<!-- Popper js -->
<script src="../js/popper.min.js"></script>
<!-- Bootstrap js -->
<script src="../js/bootstrap.min.js"></script>
<!-- Plugins js -->
<script src="../js/plugins.js"></script>
<!-- Active js -->
<script src="../js/active.js"></script>

<!--form style start-->
<!-- Main JS  -->
  <!--  <script type="text/javascript" src="assets/js/jquery-min.js"></script>  -->
    <script type="text/javascript" src="../assets/js/form-validator.min.js"></script>
    <script type="text/javascript" src="../assets/js/contact-form-script.js"></script>
<!--form style end-->



</body>

</html>
