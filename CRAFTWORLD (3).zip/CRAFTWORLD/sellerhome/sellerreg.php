<!--php Registration code start-->
<?php

include '../dbconnect.php';

if(isset($_POST['submit']))
{

$a=$_POST["name"];
$b=$_POST["email"];
$c=$_POST["mobile"];
$p=md5($_POST["password"]);
$cp = md5($_POST["cpassword"]);

$sql1 = "SELECT * FROM `tbl_login` WHERE email='$b'";

 $res1 = mysqli_query($con, $sql1);


 $sql2 = "SELECT * FROM `tbl_registration` WHERE mobile='$c'";


 $res2 = mysqli_query($con, $sql2);

  if(mysqli_num_rows($res1)>0 || mysqli_num_rows($res2)>0)
  {
      if(mysqli_num_rows($res1)>0)
	{

    echo"<script> alert('This Email is already exist!!! Please choose another one');window.location ='sellerreg.php';</script>";

    }
      if(mysqli_num_rows($res2)>0)
      {
      echo"<script> alert('This Mobile is already exist!!! Please choose another one');window.location ='sellerreg.php';</script>";


    }

}
if ($cp == $p) {



 $sql3="INSERT INTO `tbl_login`(`email`, `password`,`role_id`,`status`) VALUES ('$b','$p',3,1)";
$res3=mysqli_query($con,$sql3);

$logid="SELECT `log_id` FROM `tbl_login` WHERE `email`='$b'";
$res4=mysqli_query($con,$logid);
while($row=mysqli_fetch_array($res4))
{

  $l=$row["log_id"];
     $sql4="INSERT INTO `tbl_registration`(`name`,`mobile`,`status`) VALUES ('$a','$c',1)";

      $res5 = mysqli_query($con, $sql4);
       if(res5)
      {
      echo"<script> alert('Registration Successful Please Login');window.location ='sellerreg.php';</script>";

}
}



}

else {

       echo '<script language="javascript">';
       echo 'alert("Your password does not match")';
       echo '</script>';


}}

 ?>




<!--php Registration code end-->
















<!--
Author: Colorlib
Author URL: https://colorlib.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
  <title>CRAFT WORLD</title>

  <!-- Favicon  -->
  <link rel="icon" href="../img/core-img/2.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="../css/loginform.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">

<!-- //web font -->
<!--validation style start-->
<!-- Adding oh-autoVal css style -->
<link rel="stylesheet" type="text/css" href="jsval/oh-autoval-style.css">
<!-- Adding jQuery script. It must be before other script files -->
<script src="../jsval/jquery.min.js"> </script>
<!-- Adding oh-autoVal script file -->
<script src="../jsval/oh-autoval-script.js"></script>
<!--validation style end-->
</head>
<body>
	<!-- main -->
	<div class="main-w3layouts wrapper">
		<h1>Register Now</h1>
		<div class="main-agileinfo">
			<div class="agileits-top">
				<form action="#" class="oh-autoval-form" method="post">
          <input class="text email av-name" type="text" name="name" placeholder="Name" required="" av-message="Invalid Name" >
					<input class="text email av-email" type="email" name="email" placeholder="Email" required=""  av-message="Invalid Email">
          <input class="text email av-mobile" type="text" name="mobile" placeholder="Mobile number" required="" av-message="Invalid Mobile Number">
					<input class="text email av-password" type="password" name="password" placeholder="Password" required="" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.">
          <input class="text email" type="password" name="cpassword" placeholder="Confirm Password" required="">
					<div class="wthree-text">

						<div class="clear"> </div>
					</div>
					<input type="submit" name="submit" value="SIGNUP">
				</form>
				<p>Already have an Account? <a href="sellerlog.php"> Log In Now!</a></p>
			</div>
		</div>
		<!-- copyright -->
		<div class="colorlibcopy-agile">
			<p>©All rights reserved<a href="../index.php">CraftWorld.com</a></p>
		</div>
		<!-- //copyright -->
		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
	<!-- //main -->
</body>
</html>
