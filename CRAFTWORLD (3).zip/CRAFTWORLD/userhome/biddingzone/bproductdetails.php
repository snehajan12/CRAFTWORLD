<?php
session_start();
if(!$_SESSION['log_id'])
{
	header('location:../../index.php');
} ?>

      <?php

include('../../dbconnect.php');
if(isset($_POST['submit1']))
{

$ba=$_POST["bamount"];
$bpid=$_GET["bp_id"];
$id=$_SESSION["log_id"];
$bp=$_POST["bprice"];
$hp=$_POST["hprice"];

	$sql2=mysqli_query($con,"SELECT * FROM tbl_bidding WHERE log_id=$id");
	$q=mysqli_num_rows($sql2);

	if ($q > 0)
	{
		if($ba > $bp && $ba > $hp)
		{

	 $sql3=mysqli_query($con,"UPDATE `tbl_bidding` set b_amount='$ba' WHERE log_id='$id'");
	 if($sql3)
	{
		echo"<script> alert('Amount updated successfully');window.location ='bproductdetails.php?bp_id=$bpid';</script>";
	}
	}
	else {
			echo"<script> alert('Amount must be greater than highest bidding rate');window.location ='bproductdetails.php?bp_id=$bpid';</script>";
	}

 }
 else {

	 if($ba > $bp && $ba > $hp)
	 {

		 $sql4=mysqli_query($con,"INSERT INTO `tbl_bidding`(`log_id`,`bp_id`,`b_amount`) VALUES ($id,$bpid,'$ba')");

	 	 if($sql4)
	 	{
	 		echo"<script> alert('Amount added successfully');window.location ='bproductdetails.php?bp_id=$bpid';</script>";
	 	}
	}

		else {
				echo"<script> alert('Amount must be greater than basic bidding rate');window.location ='bproductdetails.php?bp_id=$bpid';</script>";
		}

 }
}



                  ?>



















<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>CRAFT WORLD</title>

    <!-- Favicon  -->
    <link rel="icon" href="../../img/core-img/2.png">
    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../css/core-style.css">
    <link rel="stylesheet" href="../../style.css">

</head>

<body>
    <!-- Search Wrapper Area Start -->
    <div class="search-wrapper section-padding-100">
        <div class="search-close">
            <i class="fa fa-close" aria-hidden="true"></i>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="search-content">
                        <form action="search.php" method="post">
                            <input type="search" name="search" id="search" placeholder="Type your keyword...">
                            <button type="submit"><img src="../../img/core-img/search.png" alt=""></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Search Wrapper Area End -->

    <!-- ##### Main Content Wrapper Start ##### -->
    <div class="main-content-wrapper d-flex clearfix">

        <!-- Mobile Nav (max width 767px)-->
        <div class="mobile-nav">
            <!-- Navbar Brand -->
            <div class="amado-navbar-brand">
                <a href="userhome.php"><img src="../../img/core-img/1.png" alt=""></a>
            </div>
            <!-- Navbar Toggler -->
            <div class="amado-navbar-toggler">
                <span></span><span></span><span></span>
            </div>
        </div>

        <!-- Header Area Start -->
        <header class="header-area clearfix">
            <!-- Close Icon -->
            <div class="nav-close">
                <i class="fa fa-close" aria-hidden="true"></i>
            </div>
            <!-- Logo -->
            <div class="logo">
                <a href="userhome.php"><img src="../../img/core-img/1.png" alt=""></a>
            </div>
            <!-- Amado Nav -->
            <nav class="amado-nav">
                <ul>
                  <li><a href="../userhome.php">Shop</a></li>


                  <li class="active"><a href="#">Product</a></li>
									<li><a href="../../profile/index.php">Profile</a></li>
                  <li><a href="biddinghome.php">Biddingzone</a></li>
									<li><a href="notification.php">Notification</a></li>
                </ul>
            </nav>
            <!-- Button Group -->

            <!-- Cart Menu -->

            <div class="cart-fav-search mb-100">

                <a href="#" class="search-nav"><img src="../../img/core-img/search.png" alt=""> Search</a>
								<a href="../../logout.php" class="search-nav"><img src="../../img/core-img/l.png" alt=""> Logout</a>
            </div>
            <!-- Social Button -->
            <div class="social-info d-flex justify-content-between">
                <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            </div>
        </header>
        <!-- Header Area End -->

        <!-- Product Details Area Start -->
				<?php


				$bpid=$_GET['bp_id'];


												$sql=mysqli_query($con,"SELECT b.bp_name, b.bp_id, b.bp_bprice,b.bp_edate, b.bp_image1, b.bp_image2, b.bp_image3, b.bp_image4, b.bp_description, c.category_name, r.name FROM tbl_bproduct b JOIN tbl_pcategory c ON b.pc_id = c.pc_id JOIN tbl_registration r ON b.log_id = r.log_id WHERE b.bp_id = '$bpid'");



				                $res=mysqli_num_rows($sql);


				                if($res==0)
				                {
				                  echo "no record";
				                }









            while($row=mysqli_fetch_array($sql))
             {

               ?>
        <div class="single-product-area section-padding-100 clearfix">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mt-50">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item"><a href="#"><?php echo $row['category_name'];?></a></li>

                                <li class="breadcrumb-item active" aria-current="page"><?php echo $row['bp_name'];?></li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-lg-7">
                        <div class="single_product_thumb">
                            <div id="product_details_slider" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li class="active" data-target="#product_details_slider" data-slide-to="0" style="background-image: url(../../img/bproduct-img/<?php echo $row['bp_image1'];?>">
                                    </li>
                                    <li data-target="#product_details_slider" data-slide-to="1" style="background-image: url(../../img/bproduct-img/<?php echo $row['bp_image2'];?>">
                                    </li>
                                    <li data-target="#product_details_slider" data-slide-to="2" style="background-image: url(../../img/bproduct-img/<?php echo $row['bp_image3'];?>">
                                    </li>
                                    <li data-target="#product_details_slider" data-slide-to="3" style="background-image: url(../../img/bproduct-img/<?php echo $row['bp_image4'];?>">
                                    </li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <a class="gallery_img" href="../../img/bproduct-img/<?php echo $row['bp_image1'];?>">
                                            <img class="d-block w-100" src="../../img/bproduct-img/<?php echo $row['bp_image1'];?>" alt="First slide">
                                        </a>
                                    </div>
                                    <div class="carousel-item">
                                        <a class="gallery_img" href="../../img/bproduct-img/<?php echo $row['bp_image2'];?>">
                                            <img class="d-block w-100" src="../../img/bproduct-img/<?php echo $row['bp_image2'];?>" alt="Second slide">
                                        </a>
                                    </div>
                                    <div class="carousel-item">
                                        <a class="gallery_img" href="../../img/bproduct-img/<?php echo $row['bp_image3'];?>">
                                            <img class="d-block w-100" src="../../img/bproduct-img/<?php echo $row['bp_image3'];?>" alt="Third slide">
                                        </a>
                                    </div>
                                    <div class="carousel-item">
                                        <a class="gallery_img" href="../../img/bproduct-img/<?php echo $row['bp_image4'];?>">
                                            <img class="d-block w-100" src="../../img/bproduct-img/<?php echo $row['bp_image4'];?>" alt="Fourth slide">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5">
                        <div class="single_product_desc">
                            <!-- Product Meta Data -->
                            <div class="product-meta-data">
                                <div class="line"></div>
                                <p class="product-price">Bid Rate: ₹<?php echo $row['bp_bprice'];?></p>
                                <a href="#">
                                    <h6><?php echo $row['bp_name'];?></h6>
                                </a>
                                <!-- Ratings & Review -->

                            </div>

                            <div class="short_overview my-5">
                                <p>Description: <?php echo $row['bp_description'];?></p>
																<p>Last Date: <?php echo $row['bp_edate'];?></p>
                            </div>

                            <!-- Add to Cart Form -->


                                <a data-toggle="modal" data-target="#myModal1">

                                <input type="button" name="submit2" id="submit2" value="Bid Now" class="btn amado-btn">
															</a>


                        </div>
                    </div>
                </div>
            </div>
        </div>
      <?php }  ?>
        <!-- Product Details Area End -->
    </div>
    <!-- ##### Main Content Wrapper End ##### -->


    <!-- ##### Footer Area Start ##### -->
    <footer class="footer_area clearfix">
        <div class="container">
            <div class="row align-items-center">
                <!-- Single Widget Area -->
                <div class="col-12 col-lg-4">
                    <div class="single_widget_area">
                        <!-- Logo -->
                        <div class="footer-logo mr-50">
                            <a href="index.html"><img src="../../img/core-img/logo2.png" alt=""></a>
                        </div>
                        <!-- Copywrite Text -->
                        <p class="copywrite"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved<i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">CraftWorld</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    </div>
                </div>
                <!-- Single Widget Area -->
                <div class="col-12 col-lg-8">
                    <div class="single_widget_area">
                         <!-- Footer Menu -->
                        <div class="footer_menu">
                            <nav class="navbar navbar-expand-lg justify-content-end">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#footerNavContent" aria-controls="footerNavContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
                                <div class="collapse navbar-collapse" id="footerNavContent">
                                    <ul class="navbar-nav ml-auto">

                                        <li class="nav-item">
                                            <a class="nav-link" href="userhome.php">Shop</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Product</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="cart.php">Cart</a>
                                        </li>

                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
				<!-- Modal1 -->
	      <!--bidding-->
				<?php
				$bpid=$_GET['bp_id'];


												$sql5=mysqli_query($con,"SELECT * FROM tbl_bproduct WHERE bp_id='$bpid'");



				                $res5=mysqli_num_rows($sql5);


				                if($res5==0)
				                {
				                  echo "no record";
				                }

				 ?>
	 <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-hidden="true">
	 	<div class="modal-dialog modal-dialog-centered" role="document">
	 		<div class="modal-content">
	 			<div class="modal-header text-center">
	 				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	 					<span aria-hidden="true">&times;</span>
	 				</button>
	 			</div>
	 			<div class="modal-body">
	 				<div class="login px-4 mx-auto mw-100">
	 					<h5 class="text-center mb-4">Bid Now</h5>
	 					<form action="#" method="post">
	 						<div class="form-group">
								<?php
								while($row=mysqli_fetch_array($sql5))
		             {
									  ?>
	 							<label class="mb-2">Product Name</label>
	 							<input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="" value="<?php echo $row['bp_name'];?>" required="" readonly>

	 						</div>
	 						<div class="form-group">
	 							<label class="mb-2">Starting Bid Rate</label>
	 							<input type="text" class="form-control" id="bprice" name="bprice" placeholder="" value="<?php echo $row['bp_bprice'];?>" required="" readonly>
	 						</div>
							<div class="form-group">
								<label class="mb-2">Last Date</label>
								<input type="text" class="form-control" id="password" name="password" placeholder="" value="<?php echo $row['bp_edate'];?>" required="" readonly>
							</div>
						<?php } ?>
							<div class="form-group">
								<?php
                 $id=$_GET['bp_id'];
								 
											$sql6=mysqli_query($con,"SELECT MAX(b_amount) AS hamount FROM tbl_bidding WHERE bp_id='$id'");
																$res=mysqli_num_rows($sql6);

																while($row=mysqli_fetch_array($sql6))
																 {

                ?>
	 							<label class="mb-2">Highest Bid Rate</label>
	 							<input type="text" class="form-control" id="hprice" name="hprice" placeholder="" required="" value="<?php echo $row['hamount']+0;?>" readonly>
              <?php }?>

							</div>

							<div class="form-group">

	 							<label class="mb-2">Enter Your Bid Amount</label>
	 							<input type="text" class="form-control" id="bamount" name="bamount" placeholder="" required="">
	 						</div>

	                         <button type="submit" class="btn btn-primary submit mt-2" name="submit1">SUBMIT</button>


	 					</form>
	 				</div>
	 			</div>
	 		</div>
	 	</div>
	 </div>
	 <!--//Login-->
	 <!--modal end-->
    </footer>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="../../js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../js/active.js"></script>
		<!--page refresh auction start-->
		<script src="../../external\jquery\jquery.js"></script>
		<script>
    var vehicleId = '<?php echo $_GET['bp_id']; ?>';
    setInterval(() => {
        $.post('live_auction.php', {'bp_id':vehicleId}).then(function(data){
            $("#brate1").val(data);
        });
    }, 1000);
</script>
		<!--page refresh auction end-->

</body>

</html>
