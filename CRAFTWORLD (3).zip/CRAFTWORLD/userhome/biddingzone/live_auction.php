<?php
 include "../../dbconnect.php";
 $bp_id = $_POST['bp_id'];


 //query
$sql="select max(amount) from tbl_bidding  where bp_id='$bp_id'";
$res= mysqli_query($conn,$sql);

 //exectue



 //fetch amount
$amount = mysqli_fetch_array($res);
echo $amount[0];




?>
